// resources/js/history.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Halaman Histori Transaksi siap!');
});