// resources/js/marketing.js

document.addEventListener('DOMContentLoaded', function() {
    console.log('Halaman Marketing Kit siap!');
});